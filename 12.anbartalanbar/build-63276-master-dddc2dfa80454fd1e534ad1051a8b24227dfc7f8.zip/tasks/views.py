from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
def delete_task(request, task_id):
    if request.method == 'DELETE':
        pass  # Your Code Here
