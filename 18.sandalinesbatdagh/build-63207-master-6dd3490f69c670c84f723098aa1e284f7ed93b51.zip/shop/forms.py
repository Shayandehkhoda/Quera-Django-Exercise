from django import forms


class PersonalInformation(forms.Form):
    GENDERS = (
        ('m', 'Male'),
        ('f', 'Female')
    )
    gender = forms.ChoiceField(choices=GENDERS)
    full_name = ...  # 5 <= fullname's length <= 60
    height = ...     # 70 <= height <= 250
    age = ...        # 14 <= age <= 99

    # implement full_name validation function here
    # full_name should be a title
