from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .models import Person


@csrf_exempt
def personal_page(request):
    if request.method == 'GET':
        persons = Person.objects.all()
        context = {
            'persons': persons
        }
        return render(request, 'main.html', context)

    elif request.method == 'POST':
        ...
