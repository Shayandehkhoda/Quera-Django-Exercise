# Needed imports here


def list_create_tasks(request):
    if request.method == 'GET':
        pass  # Your Code Here


def count_tasks(request):
    if request.method == 'GET':
        pass  # Your Code Here
