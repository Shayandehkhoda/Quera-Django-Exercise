from .models import Book
from django.shortcuts import render


def booklist(request):
    pass
