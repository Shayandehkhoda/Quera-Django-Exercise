from django.shortcuts import render, HttpResponse
from .models import Musician, Album


class Musician_list(...):
    # type your code here
