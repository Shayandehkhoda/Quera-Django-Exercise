from django.apps import AppConfig


class MusicianListAppConfig(AppConfig):
    name = 'musician_list_app'
