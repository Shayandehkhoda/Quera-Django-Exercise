from django.apps import AppConfig


class MobilestoreConfig(AppConfig):
    name = 'mobilestore'
