from .models import Brand, Mobile


def all_brands_not_in_korea_china():
    pass


def some_brand_mobiles(*brand_names):
    pass


def mobiles_brand_nation_equals_made_in():
    pass
