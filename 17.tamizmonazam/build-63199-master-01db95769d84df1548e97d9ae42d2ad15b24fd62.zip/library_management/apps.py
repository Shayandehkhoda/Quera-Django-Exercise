from django.apps import AppConfig


class LibraryManagementConfig(AppConfig):
    name = 'library_management'
