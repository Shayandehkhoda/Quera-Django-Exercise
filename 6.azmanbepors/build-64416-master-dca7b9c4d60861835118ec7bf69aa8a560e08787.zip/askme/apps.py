from django.apps import AppConfig


class AskmeConfig(AppConfig):
    name = 'askme'
