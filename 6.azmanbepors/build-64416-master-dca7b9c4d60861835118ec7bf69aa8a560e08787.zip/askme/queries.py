# Import stuff


def total_value_of_products():
    query = ...
    return query


def total_value_of_products_with_brand_of(brand_name):
    query = ...
    return query


def most_expensive_cheapest_price_with_nationality_of(nationality):
    query = ...
    return query


def display_size_avg_in_available_mobiles_between_price(minimum, maximum):
    query = ...
    return query
