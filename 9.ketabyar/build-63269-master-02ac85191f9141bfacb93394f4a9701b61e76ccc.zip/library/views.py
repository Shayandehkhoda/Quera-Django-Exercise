from django.http import HttpResponse

from .models import Book
from .render import render_to_readable_output


def book_list(request):
    min_price = request.GET.get('min_price') or 0
    # Other query parameters
    max_price = ...
    author = ...
    name = ...

    # fill `.filter()` with query parameters
    all_books = Book.objects.filter()

    rendered_string = render_to_readable_output(all_books)
    return HttpResponse(rendered_string)
