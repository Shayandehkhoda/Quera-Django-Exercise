from django.views.decorators.csrf import csrf_exempt
# Other required imports here


@csrf_exempt
def list_create_tasks(request):
    if request.method == 'POST':
        pass  # Your Code Here
