from .models import Musician, Album


class MusicianListView(...):
    pass  # type your code here


class AlbumDetailView(...):
    pass  # type your code here
