from django.apps import AppConfig


class SixinappConfig(AppConfig):
    name = 'sixinapp'
